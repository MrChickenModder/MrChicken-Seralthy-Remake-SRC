using HarmonyLib;
using Seralyth.Extensions;
using Seralyth.Menu;

namespace Seralyth.Patches.Menu;

[HarmonyPatch(typeof(GorillaPlayerScoreboardLine), "UpdatePlayerText")]
public class UpdatePatch
{
	public static bool enabled;

	private static int GetPing(VRRig rig)
	{
		int ping = rig.GetPing();
		return (ping <= 150) ? 5 : ((ping <= 300) ? 4 : ((ping <= 450) ? 3 : ((ping > 600) ? 1 : 2)));
	}

	public static void Postfix(GorillaPlayerScoreboardLine __instance)
	{
		if (enabled)
		{
			string playerNameVisible = Main.CleanPlayerName(__instance.linePlayer.NickName) + " ERR";
			try
			{
				VRRig val = __instance.linePlayer.VRRig();
				playerNameVisible = $"{Main.CleanPlayerName(__instance.linePlayer.NickName)}<size=50> <sprite name=\"{val.GetPlatform()}\"> <sprite name=\"Ping{GetPing(val)}\">{val.fps}</size>";
			}
			catch
			{
			}
			__instance.playerNameVisible = playerNameVisible;
		}
	}
}
