using HarmonyLib;
using Seralyth.Classes.Mods;
using TMPro;
using UnityEngine;

namespace Seralyth.Patches.Menu;

[HarmonyPatch(typeof(NewMapsDisplay), "UpdateSlideshow")]
public static class UpdateSlideshowPatch
{
	public static bool Prefix(NewMapsDisplay __instance)
	{
		if ((Object)(object)VirtualStumpAd.Instance == (Object)null)
		{
			return true;
		}
		__instance.mapImage = VirtualStumpAd.SpriteRenderer;
		__instance.mapInfoTMP = (TMP_Text)(object)VirtualStumpAd.MapInfoText.GetComponent<TextMeshPro>();
		return (Object)(object)__instance.mapImage != (Object)null && (Object)(object)((Component)__instance.mapImage).gameObject != (Object)null;
	}
}
