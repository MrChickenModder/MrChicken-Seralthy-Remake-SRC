using GorillaLocomotion.Climbing;
using HarmonyLib;
using UnityEngine;

namespace Seralyth.Patches.Menu;

public class VelocityPatches
{
	[HarmonyPatch(typeof(GorillaVelocityTracker), "GetAverageVelocity")]
	public class VelocityPatch
	{
		public static void Postfix(GorillaVelocityTracker __instance, ref Vector3 __result, bool worldSpace = false, float maxTimeFromPast = 0.15f, bool doMagnitudeCheck = false)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Unknown result type (might be due to invalid IL or missing references)
			if (enabled)
			{
				__result *= multipleFactor;
			}
		}
	}

	[HarmonyPatch(typeof(GorillaVelocityTracker), "GetLatestVelocity")]
	public class VelocityPatch2
	{
		public static void Postfix(GorillaVelocityTracker __instance, ref Vector3 __result, bool worldSpace = false)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			//IL_001b: Unknown result type (might be due to invalid IL or missing references)
			if (enabled)
			{
				__result *= multipleFactor;
			}
		}
	}

	[HarmonyPatch(typeof(GorillaVelocityEstimator), "TriggeredLateUpdate")]
	public class VelocityPatch3
	{
		public static void Postfix(GorillaVelocityEstimator __instance)
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Unknown result type (might be due to invalid IL or missing references)
			if (enabled)
			{
				__instance.linearVelocity *= multipleFactor;
				__instance.angularVelocity *= multipleFactor;
				__instance.handPos *= multipleFactor;
			}
		}
	}

	public static bool enabled;

	public static float multipleFactor;
}
