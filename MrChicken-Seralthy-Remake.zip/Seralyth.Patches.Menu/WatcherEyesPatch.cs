using GorillaLocomotion;
using HarmonyLib;
using UnityEngine;

namespace Seralyth.Patches.Menu;

[HarmonyPatch(typeof(HalloweenWatcherEyes), "Update")]
public class WatcherEyesPatch
{
	public static bool enabled;

	public static bool Prefix(HalloweenWatcherEyes __instance)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		if (enabled)
		{
			Vector3 val = ((Component)GTPlayer.Instance.headCollider).transform.position - ((Component)__instance).transform.position;
			Quaternion rotation = Quaternion.LookRotation(((Vector3)(ref val)).normalized);
			__instance.leftEye.transform.rotation = rotation;
			__instance.rightEye.transform.rotation = rotation;
			return false;
		}
		return true;
	}
}
